import unittest

from validation import validate_mark
from calculations import calculate_total, calculate_average, calculate_grade


class StudentMarksTests(unittest.TestCase):
    def test_validation(self):
        self.assertTrue(validate_mark(0))
        self.assertTrue(validate_mark(100))
        self.assertFalse(validate_mark(-5))
        self.assertFalse(validate_mark(105))

    def test_normal_marks(self):
        marks = [75, 82, 68]
        self.assertEqual(calculate_total(marks), 225)
        self.assertEqual(calculate_average(marks), 75)
        self.assertEqual(calculate_grade(75), "B")

    def test_grade_boundaries(self):
        expected = {50: "D", 60: "C", 70: "B", 80: "A"}
        for average, grade in expected.items():
            with self.subTest(average=average):
                self.assertEqual(calculate_grade(average), grade)


if __name__ == "__main__":
    unittest.main()
