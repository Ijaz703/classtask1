"""Pure calculation and grading logic for the Student Marks application."""

def calculate_total(marks):
    """Return the total of all marks."""
    return sum(marks)


def calculate_average(marks):
    """Return the average of all marks."""
    total = calculate_total(marks)
    return total / len(marks)


def calculate_grade(average):
    """Return the grade for an average using the assignment's grading rules."""
    if average >= 80:
        return "A"
    elif average >= 70:
        return "B"
    elif average >= 60:
        return "C"
    elif average >= 50:
        return "D"
    else:
        return "F"
