"""Display responsibilities for the Student Marks application."""

def display_result(name, total, average, grade):
    """Print the student's result in the required format."""
    print("\nStudent Result")
    print("----------------")
    print("Name:", name)
    print("Total:", total)
    print("Average:", average)
    print("Grade:", grade)
