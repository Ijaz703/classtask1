"""Student Marks modular project package marker."""
