"""Validation responsibilities for the Student Marks application."""

def validate_mark(mark):
    """Return True when mark is within the allowed 0-100 range."""
    return 0 <= mark <= 100
